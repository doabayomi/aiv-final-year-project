1.please install openGL if you not do it.

2.please open install.sh modify your sudo password before you run install.sh

3.if you open another console, please set the enviroment like "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:XXX"
 