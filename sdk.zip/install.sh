#install.sh
Password="123456"

#change mode
chmod 777 55-iminect-usb.rules

#move rules to /etc/udev/rules.d
echo $Password | sudo -S cp 55-iminect-usb.rules /etc/udev/rules.d
echo $Password | sudo -S udevadm control --reload-rules

#set environment
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./libs
